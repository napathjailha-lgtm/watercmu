// src/components/MeterReadings.js
import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable'; // ต้องติดตั้งและ import เพิ่ม

// กำหนดค่า API URL
const API_BASE_URL = 'https://api.abchomey.com/api';

function MeterReadings({ user, currentVillage }) {
  const [readingPeriod, setReadingPeriod] = useState({
    month: new Date().getMonth() + 1, // เดือนปัจจุบัน
    year: new Date().getFullYear()
  });

  const [readings, setReadings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showReadingForm, setShowReadingForm] = useState(false);
  const [selectedMeter, setSelectedMeter] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [notification, setNotification] = useState({
    show: false,
    message: '',
    type: 'success'
  });

  // States สำหรับการถ่ายรูป
  const [showCamera, setShowCamera] = useState(false);
  const [capturedImage, setCapturedImage] = useState(null);
  const [stream, setStream] = useState(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const months = [
    'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
    'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'
  ];

  // สร้าง Axios instance พร้อมกับ token
  const api = axios.create({
    baseURL: API_BASE_URL,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
    }
  });

  // โหลดข้อมูลการอ่านมิเตอร์เมื่อคอมโพเนนต์โหลดหรือเมื่อเปลี่ยนงวด
  useEffect(() => {
    if (currentVillage?.village_id) {
      fetchMeterReadings();
    }
  }, [readingPeriod, currentVillage]);

  // ปิดกล้องเมื่อ component unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  // ฟังก์ชันเปิดกล้อง
  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment', // ใช้กล้องหลัง
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });

      setStream(mediaStream);
      setShowCamera(true);

      // รอให้ video element โหลด
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      }, 100);

    } catch (err) {
      console.error('Error accessing camera:', err);
      showNotification('ไม่สามารถเปิดกล้องได้ กรุณาตรวจสอบการอนุญาต', 'error');
    }
  };

  // ฟังก์ชันปิดกล้อง
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setShowCamera(false);
  };

  // ฟังก์ชันถ่ายรูป
  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0);

      // แปลงเป็น blob
      canvas.toBlob((blob) => {
        const imageUrl = URL.createObjectURL(blob);
        setCapturedImage({
          blob: blob,
          url: imageUrl,
          file: new File([blob], `meter-${selectedMeter?.meterNumber}-${Date.now()}.jpg`, {
            type: 'image/jpeg'
          })
        });
        stopCamera();
      }, 'image/jpeg', 0.8);
    }
  };

  // ฟังก์ชันลบรูปที่ถ่าย
  const removeCapturedImage = () => {
    if (capturedImage?.url) {
      URL.revokeObjectURL(capturedImage.url);
    }
    setCapturedImage(null);
  };

  // ฟังก์ชันอัพโหลดรูป
  const uploadImage = async (file) => {
    const formData = new FormData();
    formData.append('meter_photo', file);
    formData.append('meter_id', selectedMeter.meterId);

    try {
      const response = await axios.post(`${API_BASE_URL}/upload/meter-photo`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });

      return response.data.photo_url;
    } catch (error) {
      console.error('Error uploading image:', error);
      throw new Error('ไม่สามารถอัพโหลดรูปภาพได้');
    }
  };

  // ดึงข้อมูลการอ่านมิเตอร์จาก API

  const fetchMeterReadings = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await api.get(`/readings/village/${currentVillage.village_id}`, {
        params: {
          village_id: currentVillage.village_id,
          month: readingPeriod.month,
          year: readingPeriod.year,
          // ลบ search: searchTerm, ออกไป
          status: statusFilter !== 'all' ? statusFilter : undefined // ยังคง status filter ไว้หากต้องการ
        }
      });
      // console.log('dart',response.data.data)
      if (response.data && response.data.success) {

        const formattedReadings = response.data.data.map(reading => (
          console.log('งงงวย', reading),
          {

            id: reading.reading_id,
            meterNumber: reading.meter_number,
            meterId: reading.meter_id,
            resident: reading.customer_name,
            address: reading.address,
            previousReading: reading.current_month_previous_reading != null ? Number(reading.current_month_previous_reading) : Number(reading.previous_month_reading) ? Number(reading.previous_month_reading) : Number(reading.meter_read),
            currentReading: reading.current_month_reading != null ? Number(reading.current_month_reading) : null,
            usage: reading.current_month_reading != null ? Number(reading.current_month_reading - (reading.current_month_previous_reading || reading.meter_read)) : null,
            readDate: reading.current_month_reading_date ? formatDateThai(reading.current_month_reading_date) : null,
            status: reading.status, // 'pending', 'verified', 'unread'
            reader: reading.current_month_reader_name,
            readerId: reading.reader_id,
            note: reading.note,
            photoUrl: reading.current_month_reading_image,
            createdAt: reading.created_at,
            updatedAt: reading.updated_at
          }));

        setReadings(formattedReadings); // เก็บข้อมูลทั้งหมดที่ได้จาก API ไว้ใน state
      } else {
        throw new Error(response.data?.message || 'ไม่สามารถดึงข้อมูลการอ่านมิเตอร์ได้');
      }
    } catch (err) {
      console.error('Error fetching meter readings:', err);
      setError(err.response?.data?.message || err.message || 'เกิดข้อผิดพลาดในการโหลดข้อมูล');
      showNotification('เกิดข้อผิดพลาด: ' + (err.response?.data?.message || err.message), 'error');
    } finally {
      setLoading(false);
    }
  };


  // แปลงวันที่เป็นรูปแบบไทย
  const formatDateThai = (dateString) => {
    if (!dateString) return null;

    const date = new Date(dateString);
    return date.toLocaleDateString('th-TH', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  // แสดงตัวเลขแบบปลอดภัย
  const formatNumber = (value) => {
    if (value == null || value === undefined || isNaN(value)) {
      return '-';
    }
    return Number(value).toLocaleString();
  };

  // แสดงการแจ้งเตือน
  const showNotification = (message, type = 'success') => {
    setNotification({
      show: true,
      message,
      type
    });

    setTimeout(() => {
      setNotification(prev => ({ ...prev, show: false }));
    }, 5000);
  };

  const handleMonthChange = (e) => {
    setReadingPeriod(prev => ({
      ...prev,
      month: parseInt(e.target.value)
    }));
  };

  const handleYearChange = (e) => {
    setReadingPeriod(prev => ({
      ...prev,
      year: parseInt(e.target.value)
    }));
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };
  const filteredReadings = readings.filter(meter => {
    const lowerCaseSearchTerm = searchTerm.toLowerCase();
    const meterNumberMatch = meter.meterNumber.toLowerCase().includes(lowerCaseSearchTerm);
    const customerNameMatch = meter.resident.toLowerCase().includes(lowerCaseSearchTerm);
    const addressMatch = meter.address?.toLowerCase().includes(lowerCaseSearchTerm);
    const readerMatch = meter.reader?.toLowerCase().includes(lowerCaseSearchTerm); // เพิ่มค้นหาจากคนอ่าน

    const statusMatch = statusFilter === 'all' ||
      (statusFilter === 'read' && meter.currentReading !== null) ||
      (statusFilter === 'unread' && meter.currentReading === null);

    return (meterNumberMatch || customerNameMatch || addressMatch || readerMatch) && statusMatch;
  });

  const handleStatusFilterChange = (e) => {
    setStatusFilter(e.target.value);
  };


  const drawInvoiceVerticalHalfPage = async (doc, bill, village, offsetY) => {
    const totalPageWidth = doc.internal.pageSize.getWidth(); // 210 mm for A4 portrait
    const singleInvoiceHeight = doc.internal.pageSize.getHeight() / 2; // ~148.5 mm for half A4 portrait height
    const marginX = 10; // Left/Right margin for the full width of the invoice
    let currentY = 10 + offsetY; // Starting Y position for this half-page, adjusted by offsetY

    // --- Header Section ---
    const logoWidth = 25;
    const logoHeight = 25;
    const logoX = marginX; // Logo X position is fixed on the left margin
    const logoY = currentY;

    if (village.logo_url) {
      try {
        const logoImg = await toBase64(village.logo_url);
        if (logoImg) {
          doc.addImage(logoImg, 'PNG', logoX, logoY - 5, logoWidth, logoHeight);
        }
      } catch (error) {
        console.error("Failed to load or add village logo:", error);
      }
    }

    const addressTextX = logoX + logoWidth + 3;

    const formatReadingDate = (dateObj) => {
      if (dateObj instanceof Date && !isNaN(dateObj.getTime())) {
        return dateObj.toLocaleDateString('th-TH', {
          year: 'numeric',
          month: 'numeric',
          day: 'numeric'
        });
      }
      return 'N/A';
    };

    const parseMonthYearToDate = (monthYearString) => {
      if (!monthYearString || typeof monthYearString !== 'string') {
        return null;
      }
      const parts = monthYearString.split('/');
      if (parts.length !== 2) {
        return null;
      }
      const month = parseInt(parts[0], 10);
      const year = parseInt(parts[1], 10);

      if (isNaN(month) || isNaN(year) || month < 1 || month > 12) {
        return null;
      }
      return new Date(year, month - 1, village.payment_due_date);
    };

    let currentAddressY = currentY;

    doc.setFontSize(16);
    if (village.village_name) {
      doc.text(`หมู่บ้าน ${village.village_name}`, addressTextX, currentAddressY);
    }
    currentAddressY += 6;

    doc.setFontSize(10);
    if (village.office_address) {
      doc.text('เลขที่ ' + village.office_address, addressTextX, currentAddressY);
    }
    currentAddressY += 4;
    if (village.sub_district) {
      doc.text('ตำบล ' + village.sub_district, addressTextX, currentAddressY);
    }
    currentAddressY += 4;
    if (village.district) {
      doc.text('อำเภอ ' + village.district, addressTextX, currentAddressY);
    }
    currentAddressY += 4;

    if (village.province) {
      doc.text('จังหวัด ' + village.province, addressTextX, currentAddressY);
    }
    currentAddressY += 4;

    if (village.postal_code) {
      doc.text('รหัสไปรษณีย์ ' + village.postal_code, addressTextX, currentAddressY);
    }
    currentAddressY += 4;
    if (village.phone_number || village.tax_id) {
      doc.text(`โทร ${village.phone_number || 'xxx-xxxxxxx'} เลขประจำตัวผู้เสียภาษี ${village.tax_id || ''}`, addressTextX, currentAddressY);
    }

    currentY = Math.max(currentAddressY + 5, logoY + logoHeight + 5); // Ensure currentY is below logo/address

    // Invoice Header (Top Right)
    doc.setFontSize(16);
    doc.text('ใบแจ้งหนี้/INVOICE', totalPageWidth - marginX, logoY, { align: 'right' });

    // Invoice Details (Right Side)
    doc.setFontSize(10);
    let invoiceNumberFormatted = 'N/A';
    if (bill.billing_month && bill.bill_id) {
      const [month, year] = bill.billing_month.split('/');
      const formattedMonth = month.padStart(2, '0');
      invoiceNumberFormatted = `${year}${formattedMonth}${bill.bill_id}`;
    }
    doc.text(`เลขที่ใบแจ้งหนี้/Invoice No: ${invoiceNumberFormatted}`, totalPageWidth - marginX, logoY + 10, { align: 'right' });
    doc.text(`วันที่ออกใบแจ้งหนี้/Issued Date: ${formatReadingDate(new Date(bill.current_meter_date))}`, totalPageWidth - marginX, logoY + 15, { align: 'right' });
    doc.text(`วันที่ครบกำหนดชำระ/Due Date: ${parseMonthYearToDate(bill.billing_month) ? new Date(parseMonthYearToDate(bill.billing_month)).toLocaleDateString('th-TH') : 'N/A'}`, totalPageWidth - marginX, logoY + 20, { align: 'right' });

    //currentY = Math.max(currentY + 8); // Ensure currentY is below invoice details
    currentY = currentY - 4;
    // Customer Details (Left Side)
    doc.setFontSize(10);
    doc.text(`บ้านเลขที่/Code: ${bill.house_number || bill.address || 'N/A'}`, marginX, currentY);
    currentY += 5;
    doc.text(`ชื่อผู้ใช้น้ำ/NAME: ${bill.customer_name || 'N/A'}`, marginX, currentY);
    currentY += 5;

    // Table Header for Usage Details
    doc.setFontSize(10);
    doc.setFillColor(230, 230, 230);
    doc.rect(marginX, currentY, (totalPageWidth - 50) - (2 * marginX), 6, 'F'); // Full width of the content area
    doc.setTextColor(0, 0, 0);
    doc.text('ลำดับ/No.', marginX + 3, currentY + 4);
    doc.text('รายละเอียด/Description', marginX + 20, currentY + 4, { align: 'left' });
    doc.text('จำนวนหน่วยที่ใช้/Units Used', totalPageWidth - marginX - 100, currentY + 4, { align: 'right' });
    doc.text('จำนวนเงิน/Amount', totalPageWidth - marginX - 55, currentY + 4, { align: 'right' });
    currentY += 6;

    // Table Body - Water Bill
    doc.text('1', marginX + 3, currentY + 4);
    doc.text('ค่าน้ำประปา', marginX + 15, currentY + 4);
    doc.text(`${bill.water_usage || '0'}`, totalPageWidth - marginX - 110, currentY + 4, { align: 'right' });
    doc.text(`${formatNumber(bill.base_amount)}`, totalPageWidth - marginX - 60, currentY + 4, { align: 'right' });
    currentY += 6;

    // Water Meter Reading Description
    doc.setFontSize(9);



    const currentBillingDateObj = parseMonthYearToDate(bill.billing_month);
    let previousBillingDateObj = null;
    if (currentBillingDateObj) {
      previousBillingDateObj = new Date(currentBillingDateObj);
      previousBillingDateObj.setMonth(previousBillingDateObj.getMonth() - 1); // For previous month's reading
    }
    const currentReadingDateStr = formatReadingDate(new Date(bill.current_meter_date));
    const previousReadingDateStr = formatReadingDate(new Date(bill.previous_meter_data));
    const previousReadingLine = `ครั้งก่อน ${previousReadingDateStr} เลขมิเตอร์  ${bill.previous_meter_reading || '0'} ครั้งนี้ ${currentReadingDateStr} เลขมิเตอร์  ${bill.current_meter_reading || '0'}`;
    doc.text(previousReadingLine, marginX + 15, currentY + 3);
    //currentY += 5;
    //doc.text(currentReadingLine, marginX + 15, currentY + 6);

    currentY += 5;

    // Add Images
    const imgXOffset = marginX + 5;
    const imgWidth = 45;
    const imgHeight = 35;
    const imgSpacing = 5;

    if (bill.previous_meter_image_url) {
      try {
        const img1 = await toBase64(bill.previous_meter_image_url);
        if (img1) {
          doc.addImage(img1, 'PNG', totalPageWidth - imgXOffset - 35, currentY + -20, imgWidth, imgHeight);
          doc.text('ภาพมิเตอร์ครั้งก่อน', totalPageWidth - imgWidth + 17, currentY + imgHeight - 15, { align: 'center' });
        }
      } catch (error) {
        console.error("Failed to load current meter image:", error);
      }
    }
    if (bill.current_meter_image_url) {
      try {
        const img2 = await toBase64(bill.current_meter_image_url);
        if (img2) {
          // Adjusted position for the second image to be beside the first
          doc.addImage(img2, 'PNG', totalPageWidth - imgXOffset - 35, currentY + 30, imgWidth, imgHeight);
          doc.text('ภาพมิเตอร์ปัจจุบัน', totalPageWidth - imgWidth + 17, currentY + imgHeight + 35, { align: 'center' });
        }
      } catch (error) {
        console.error("Failed to load previous meter image:", error);
      }
    }
    currentY += imgHeight - 10;
    // Bill Summary Section
    doc.setFontSize(9);
    // doc.rect(marginX, currentY, (totalPageWidth-50) - (2 * marginX), 6, 'F');
    doc.line(marginX, currentY, totalPageWidth - 62, currentY);
    currentY += 4;
    doc.text('จำนวนเงินเดือนนี้', marginX, currentY);
    doc.text(`${formatNumber(bill.base_amount) || '0.00'}`, totalPageWidth - marginX - 55, currentY, { align: 'right' });
    currentY += 5;

    doc.text('ค่าบำรุง', marginX, currentY);
    doc.text(`${bill.additional_fees_amount || '0.00'}`, totalPageWidth - marginX - 55, currentY, { align: 'right' });
    currentY += 5;

    doc.text('ค่าใช้จ่ายอื่นๆ', marginX, currentY);
    doc.text(`${bill.other_charges || '0.00'}`, totalPageWidth - marginX - 55, currentY, { align: 'right' });
    currentY += 5;

    doc.text('เงินเพิ่มชำระล่าช้า', marginX, currentY);
    doc.text('0.00', totalPageWidth - marginX - 55, currentY, { align: 'right' });
    currentY += 5;

    // Total Amount
    doc.setFontSize(10);
    doc.line(marginX, currentY, totalPageWidth - marginX - 50, currentY);
    currentY += 1;
    doc.line(marginX, currentY, totalPageWidth - marginX - 50, currentY);
    currentY += 4;
    doc.setFontSize(12);
    doc.text('รวมทั้งสิ้น', marginX, currentY);
    doc.text(`${formatNumber(bill.total_amount) || '0.00'}`, totalPageWidth - marginX - 55, currentY, { align: 'right' });
    doc.setFontSize(10);
    const amountInWords = convertBahtToThaiWords(bill.total_amount);
    doc.text(amountInWords, (totalPageWidth / 2) - 20, currentY, { align: 'center' }); // Centered for full width
    currentY += 2;
    doc.line(marginX, currentY, totalPageWidth - marginX - 50, currentY);
    currentY += 1;
    doc.line(marginX, currentY, totalPageWidth - marginX - 50, currentY);
    currentY += 5;
    doc.setFontSize(9);
    doc.text('ช่องทางการชำระเงิน', marginX, currentY);
    currentY += 5;
    doc.text('1. เงินสด', marginX, currentY);
    doc.text(`เบอร์โทร. ${village.contact_phone || 'กรุณาติดต่อผู้ดูแลของคุณ'}`, totalPageWidth - marginX - 50, currentY - 5, { align: 'right' });
    currentY += 5;

    doc.text(`2. โอนเงินเข้าบัญชี ธนาคาร ${village.bank_name || 'กรุณาติดต่อผู้ดูแล'} เลขที่บัญชี ${village.account_number || 'กรุณาติดต่อผู้ดูแล'}`, marginX, currentY);
    doc.line(totalPageWidth - marginX - 50, currentY, totalPageWidth - marginX - 80, currentY);
    //currentY += 4;
    doc.text(`(${village.contact_person || 'N/A'})`, totalPageWidth - marginX - 55, currentY + 5, { align: 'right' });
    const qrXOffset = marginX + 50;

    currentY += 4;
    const qrWidth = 20;
    const qrHeight = 20;
    if (village.qr_code_url) {
      try {
        const qrImg1 = await toBase64(village.qr_code_url);
        if (qrImg1) {
          doc.addImage(qrImg1, 'PNG', qrXOffset + 25, currentY - 18, qrWidth, qrHeight);
        }
      } catch (error) {
        console.error("Failed to load QR code 1:", error);
      }
    }
    currentY += qrHeight;
    doc.text(`เมื่อชำระเงินแล้ว กรุณาส่งสำเนาการชำระเงินมาที่ : E-mail ${village.contact_email || 'N/A'}`, marginX, currentY - 20);
    //currentY += 5;
    doc.setFontSize(10);
    doc.text('ผู้แจ้งยอด', totalPageWidth - marginX - 57, currentY - 15, { align: 'right' });
  };
  const convertBahtToThaiWords = (amount) => {
    const units = ['', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า'];
    const places = ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน'];

    const convertLessThanMillion = (num) => {
      let result = '';
      let s = num.toString();
      let len = s.length;

      for (let i = 0; i < len; i++) {
        let digit = parseInt(s[i], 10);
        let placeIndex = len - i - 1;

        if (digit === 0) continue;

        if (placeIndex === 1 && digit === 1) { // "สิบ" (for 10-19)
          result += places[1];
        } else if (placeIndex === 1 && digit === 2) { // "ยี่สิบ" (for 20-29)
          result += 'ยี่' + places[1];
        } else {
          result += units[digit];
          if (placeIndex > 0) {
            result += places[placeIndex];
          }
        }
      }
      // Handle "เอ็ด"
      if (len > 1 && s[len - 1] === '1' && s[len - 2] !== '0' && s[len - 2] !== '1') {
        result = result.replace(/หนึ่ง$/, 'เอ็ด');
      }
      return result;
    };

    if (amount === 0) return 'ศูนย์บาทถ้วน';
    if (amount < 0) return 'ไม่สามารถแปลงจำนวนเงินติดลบได้';

    let totalAmountFixed = parseFloat(amount).toFixed(2);
    let [bahtStr, satangStr] = totalAmountFixed.split('.');

    const baht = parseInt(bahtStr, 10);
    const satang = parseInt(satangStr, 10);

    let finalResult = '';

    if (baht > 0) {
      const millionPart = Math.floor(baht / 1000000);
      const remainderBaht = baht % 1000000;

      if (millionPart > 0) {
        finalResult += convertLessThanMillion(millionPart) + 'ล้าน';
        if (remainderBaht === 0) {
          finalResult += 'บาทถ้วน';
          return finalResult;
        }
      }
      finalResult += convertLessThanMillion(remainderBaht) + 'บาท';
    } else {
      finalResult += 'ศูนย์บาท';
    }

    if (satang > 0) {
      finalResult += convertLessThanMillion(satang) + 'สตางค์';
    } else {
      finalResult += 'ถ้วน';
    }

    return finalResult;
  };
  async function toBase64(url) {
    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  const handlePrintSingleBill = async (bill, village) => {
    const doc = new jsPDF('p', 'mm', 'a4');
    doc.setFont('THSarabunNew', 'normal');
    const singleInvoiceHeight = doc.internal.pageSize.getHeight() / 2;
    await drawInvoiceVerticalHalfPage(doc, bill, village, 0);
    doc.setDrawColor(150, 150, 150);
    doc.line(10, singleInvoiceHeight, doc.internal.pageSize.getWidth() - 10, singleInvoiceHeight); // Line across the middle
    doc.setDrawColor(0, 0, 0); // Reset draw color

    await drawInvoiceVerticalHalfPage(doc, bill, village, singleInvoiceHeight); // offsetY = singleInvoiceHeight for the bottom section

    doc.save(`Bill_${bill.meter_number || 'unknown'}.pdf`);
  };

  const handleReadingClick = (meter) => {
    setSelectedMeter(meter);
    setShowReadingForm(true);
    if (meter.photoUrl) {
      setCapturedImage({
        url: meter.photoUrl,
        blob: null, // No blob since it's an existing URL, not a newly captured one
        file: null  // No file since it's an existing URL
      });
    } else {
      setCapturedImage(null); // Reset if no photo
    }
  };

  const handleReadingSubmit = async (e) => {
    e.preventDefault();

    const readingValue = parseInt(e.target.reading.value);
    const note = e.target.note.value;

    // ตรวจสอบค่ามิเตอร์
    //  if (readingValue < (selectedMeter.previousReading || 0)) {
    //    showNotification('ค่ามิเตอร์ต้องมากกว่าหรือเท่ากับค่าก่อนหน้า', 'error');
    //    return;
    //  }

    setLoading(true);

    try {
      let photoUrl = null;

      // อัพโหลดรูปถ้ามี
      if (capturedImage?.file) {
        photoUrl = await uploadImage(capturedImage.file);
      }

      if (capturedImage?.url) {
        photoUrl = capturedImage.url; // ใช้ URL ที่มีอยู่
      }

      const readingData = {
        meter_id: selectedMeter.meterId,
        current_reading: readingValue,
        previous_reading: selectedMeter.previousReading || 0,
        usage: readingValue - (selectedMeter.previousReading || 0),
        read_date: new Date().toISOString().split('T')[0], // YYYY-MM-DD
        month: readingPeriod.month,
        year: readingPeriod.year,
        note: note,
        reader_id: user.user_id,
        photo_url: photoUrl,
        reading_image: photoUrl // เพิ่มรูปภาพ
      };
      console.log('Reading Data:', readingData);



      let response;

      if (selectedMeter.id && selectedMeter.currentReading !== null) {
        // แก้ไขค่าที่มีอยู่แล้ว - PUT
        response = await api.put(`/readings/${selectedMeter.id}`, readingData);
      } else {
        // เพิ่มค่าใหม่ - POST
        response = await api.post('/readings', readingData);
      }

      if (response.data && response.data.success) {
        // รีเฟรชข้อมูล
        await fetchMeterReadings();

        showNotification('บันทึกค่ามิเตอร์เรียบร้อยแล้ว', 'success');

        // ปิด form และล้างข้อมูล
        setShowReadingForm(false);
        setSelectedMeter(null);
        removeCapturedImage();
      } else {
        throw new Error(response.data?.message || 'ไม่สามารถบันทึกค่ามิเตอร์ได้');
      }
    } catch (err) {
      console.error('Error saving meter reading:', err);
      showNotification('เกิดข้อผิดพลาด: ' + (err.response?.data?.message || err.message), 'error');
    } finally {
      setLoading(false);
    }
  };

  const verifyReading = async (id) => {
    setLoading(true);

    try {
      const response = await api.patch(`/readings/${id}/verify`, {
        verified_by: user.user_id,
        verified_at: new Date().toISOString()
      });

      if (response.data && response.data.success) {
        // อัพเดท state
        setReadings(prev => prev.map(meter => {
          if (meter.id === id) {
            return {
              ...meter,
              status: 'verified'
            };
          }
          return meter;
        }));

        showNotification('ตรวจสอบค่ามิเตอร์เรียบร้อยแล้ว', 'success');
      } else {
        throw new Error(response.data?.message || 'ไม่สามารถตรวจสอบค่ามิเตอร์ได้');
      }
    } catch (err) {
      console.error('Error verifying meter reading:', err);
      showNotification('เกิดข้อผิดพลาด: ' + (err.response?.data?.message || err.message), 'error');
    } finally {
      setLoading(false);
    }
  };

  const getPendingCount = () => {
    return readings.filter(meter => meter.status === 'pending').length;
  };

  const getCompletedCount = () => {
    return readings.filter(meter => meter.currentReading !== null).length;
  };

  const getUnreadCount = () => {
    return readings.filter(meter => meter.currentReading === null).length;
  };

  // Component สำหรับแสดงรูปภาพ (แก้ปัญหา CORS)
  const ImageDisplay = ({ photoUrl, meterNumber }) => {
    const [imageError, setImageError] = useState(false);
    const [imageLoading, setImageLoading] = useState(true);


    const proxyUrl = (photoUrl);

    // ฟังก์ชันแสดงรูปขนาดใหญ่
    const showLargeImage = () => {
      if (!proxyUrl) return;

      // สร้าง modal สำหรับแสดงรูปขนาดใหญ่
      const modal = document.createElement('div');
      modal.style.cssText = `
        position: fixed; top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.9); display: flex; justify-content: center;
        align-items: center; z-index: 1001; cursor: pointer;
      `;

      const container = document.createElement('div');
      container.style.cssText = `
        max-width: 90%; max-height: 90%; display: flex; flex-direction: column;
        align-items: center; background: white; padding: 20px; border-radius: 8px;
        position: relative;
      `;

      const img = document.createElement('img');
      img.src = proxyUrl;
      img.crossOrigin = 'anonymous'; // เพิ่ม crossOrigin
      img.style.cssText = `
        max-width: 100%; max-height: 80vh; object-fit: contain;
        border-radius: 4px;
      `;

      const caption = document.createElement('p');
      caption.textContent = `รูปมิเตอร์: ${meterNumber}`;
      caption.style.cssText = `
        margin: 10px 0 0 0; font-weight: bold; color: #333;
      `;

      const closeBtn = document.createElement('button');
      closeBtn.textContent = '× ปิด';
      closeBtn.style.cssText = `
        position: absolute; top: 10px; right: 10px;
        background: rgba(0,0,0,0.7); color: white; border: none;
        padding: 8px 12px; border-radius: 4px; cursor: pointer;
        font-size: 14px; font-weight: bold;
      `;

      // Loading indicator
      const loadingDiv = document.createElement('div');
      loadingDiv.textContent = 'กำลังโหลดรูป...';
      loadingDiv.style.cssText = `
        position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
        color: #666; font-size: 16px;
      `;

      container.appendChild(loadingDiv);
      container.appendChild(img);
      container.appendChild(caption);
      container.appendChild(closeBtn);
      modal.appendChild(container);

      const closeModal = () => {
        if (document.body.contains(modal)) {
          document.body.removeChild(modal);
        }
      };

      // เมื่อรูปโหลดเสร็จ
      img.onload = () => {
        if (container.contains(loadingDiv)) {
          container.removeChild(loadingDiv);
        }
      };

      // เมื่อรูปโหลดไม่ได้
      img.onerror = () => {
        loadingDiv.textContent = 'ไม่สามารถโหลดรูปได้';
        loadingDiv.style.color = '#dc3545';
      };

      modal.onclick = closeModal;
      closeBtn.onclick = closeModal;

      // ป้องกันการปิดเมื่อคลิกรูป
      container.onclick = (e) => e.stopPropagation();

      document.body.appendChild(modal);
    };

    if (imageError || !proxyUrl) {
      return (
        <div style={{
          width: '50px',
          height: '50px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#f8f9fa',
          border: '1px solid #dee2e6',
          borderRadius: '4px',
          fontSize: '10px',
          color: '#6c757d',
          textAlign: 'center'
        }}>
          ไม่มีรูป
        </div>
      );
    }

    return (
      <div style={{ position: 'relative' }}>
        <img
          src={photoUrl}
          alt={`รูปมิเตอร์ ${meterNumber}`}
          crossOrigin="anonymous"
          style={{
            width: '50px',
            height: '50px',
            objectFit: 'cover',
            borderRadius: '4px',
            cursor: 'pointer',
            border: '1px solid #dee2e6',
            transition: 'transform 0.2s, box-shadow 0.2s'
          }}
          onMouseEnter={(e) => {
            e.target.style.transform = 'scale(1.1)';
            e.target.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
          }}
          onMouseLeave={(e) => {
            e.target.style.transform = 'scale(1)';
            e.target.style.boxShadow = 'none';
          }}
          onLoad={() => setImageLoading(false)}
          onClick={showLargeImage}
          onError={() => {
            console.error('Failed to load image via proxy:', proxyUrl);
            console.log('Original URL:', photoUrl);
            setImageError(true);
            setImageLoading(false);
          }}
          title={`คลิกเพื่อดูรูปขนาดใหญ่ - ${meterNumber}`}
        />

        {/* Loading overlay */}
        {imageLoading && (
          <div style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(255,255,255,0.8)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: '4px',
            fontSize: '10px',
            color: '#666'
          }}>
            ...
          </div>
        )}

        {/* Badge แสดงว่ามีรูป */}
        {!imageLoading && !imageError && (
          <div style={{
            position: 'absolute',
            top: '-5px',
            right: '-5px',
            width: '16px',
            height: '16px',
            backgroundColor: '#28a745',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '10px',
            color: 'white',
            fontWeight: 'bold'
          }}>
            ✓
          </div>
        )}
      </div>
    );
  };

  // สร้างปีสำหรับ dropdown
  const getYearOptions = () => {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let i = currentYear - 2; i <= currentYear + 1; i++) {
      years.push(i);
    }
    return years;
  };

  return (
    <div className="readings-container">
      {/* Notification */}
      {notification.show && (
        <div
          className={`notification ${notification.type}`}
          style={{
            position: 'fixed',
            top: 24,
            right: 24,
            zIndex: 2000,
            minWidth: 280,
            maxWidth: 360,
            padding: '18px 24px 18px 18px',
            borderRadius: 10,
            boxShadow: '0 4px 24px rgba(0,0,0,0.15)',
            color: notification.type === 'error' ? '#fff' : '#155724',
            background:
              notification.type === 'success'
                ? '#d1fae5'
                : notification.type === 'error'
                  ? '#ef4444'
                  : '#fffbe6',
            border:
              notification.type === 'success'
                ? '2px solid #10b981'
                : notification.type === 'error'
                  ? '2px solid #dc2626'
                  : '2px solid #facc15',
            display: 'flex',
            alignItems: 'center',
            fontSize: 16,
            fontWeight: 500,
            gap: 12,
          }}
        >
          <span style={{
            fontSize: 22,
            marginRight: 8,
            display: 'flex',
            alignItems: 'center'
          }}>
            {notification.type === 'success' && '✅'}
            {notification.type === 'error' && '❌'}
            {notification.type === 'warning' && '⚠️'}
          </span>
          <span style={{ flex: 1 }}>{notification.message}</span>
          <button
            className="notification-close"
            onClick={() => setNotification(prev => ({ ...prev, show: false }))}
            style={{
              background: 'none',
              border: 'none',
              fontSize: 22,
              color: notification.type === 'error' ? '#fff' : '#333',
              cursor: 'pointer',
              marginLeft: 8,
              lineHeight: 1,
            }}
            aria-label="ปิดการแจ้งเตือน"
          >
            ×
          </button>
        </div>
      )}

      <header className="page-header">
        <div className="header-content">
          <h1>บันทึกค่ามิเตอร์</h1>
          {currentVillage && (
            <div className="village-info">
              หมู่บ้าน: {currentVillage.village_name}
            </div>
          )}
        </div>
      </header>

      <div className="period-selector">
        <div className="period-label">งวดการอ่านมิเตอร์:</div>
        <div className="period-controls">
          <select value={readingPeriod.month} onChange={handleMonthChange} disabled={loading}>
            {months.map((month, index) => (
              <option key={index} value={index + 1}>{month}</option>
            ))}
          </select>
          <select value={readingPeriod.year} onChange={handleYearChange} disabled={loading}>
            {getYearOptions().map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>
          <button
            className="refresh-btn"
            onClick={fetchMeterReadings}
            disabled={loading}
          >
            {loading ? 'กำลังโหลด...' : 'รีเฟรช'}
          </button>
        </div>

        <div className="reading-stats">
          <div className="stat-box">
            <div className="stat-label">ทั้งหมด</div>
            <div className="stat-value">{readings.length}</div>
          </div>
          <div className="stat-box">
            <div className="stat-label">อ่านแล้ว</div>
            <div className="stat-value">{getCompletedCount()}</div>
          </div>
          <div className="stat-box">
            <div className="stat-label">ยังไม่ได้อ่าน</div>
            <div className="stat-value">{getUnreadCount()}</div>
          </div>
        </div>
      </div>

      <div
        className="reading-filters"
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          gap: 16,
          alignItems: 'center',
          margin: '24px 0'
        }}
      >
        <input
          type="text"
          placeholder="ค้นหาตามเลขมิเตอร์ ชื่อผู้ใช้น้ำ ที่อยู่ หรือคนอ่านมิเตอร์"
          value={searchTerm}
          onChange={handleSearchChange}
          disabled={loading}
          style={{
            flex: 1,
            minWidth: 220,
            padding: '10px 14px',
            border: '1px solid #d1d5db',
            borderRadius: 6,
            fontSize: 16
          }}
        />
        <select
          value={statusFilter}
          onChange={handleStatusFilterChange}
          disabled={loading}
          style={{
            minWidth: 140,
            padding: '10px 14px',
            border: '1px solid #d1d5db',
            borderRadius: 6,
            fontSize: 16
          }}
        >
          <option value="all">ทุกสถานะ</option>
          <option value="read">อ่านแล้ว</option>
          <option value="unread">ยังไม่ได้อ่าน</option>
        </select>
      </div>

      {/* Error Display */}
      {error && (
        <div className="error-message">
          <strong>เกิดข้อผิดพลาด:</strong> {error}
          <button onClick={fetchMeterReadings} className="retry-btn">ลองใหม่</button>
        </div>
      )}

      {/* Loading Indicator */}
      {loading && (
        <div className="loading-indicator">
          กำลังโหลดข้อมูล...
        </div>
      )}

      <div className="readings-list">
        <table className="readings-table">
          <thead>
            <tr>
              <th>เลขมิเตอร์</th>
              <th>ชื่อผู้ใช้น้ำ</th>
              <th>ที่อยู่</th>
              <th>ค่าก่อนหน้า</th>
              <th>ค่าปัจจุบัน</th>
              <th>ใช้ไป</th>
              <th>วันที่อ่าน</th>
              <th>ผู้อ่าน</th>
              <th>รูปภาพ</th>
              <th>สถานะ</th>
              <th>การจัดการ</th>
            </tr>
          </thead>
          <tbody>
            {filteredReadings.length > 0 ? (
              filteredReadings.map(meter => (
                <tr key={meter.meterId}>
                  <td>{meter.meterNumber}</td>
                  <td>{meter.resident}</td>
                  <td>{meter.address}</td>

                  <td>{formatNumber(meter.previousReading)}</td>
                  <td>{formatNumber(meter.currentReading)}</td>
                  <td>{meter.usage != null ? `${formatNumber(meter.usage)} หน่วย` : '-'}</td>
                  <td>{meter.readDate || '-'}</td>
                  <td>{meter.reader || '-'}</td>
                  <td>
                    <ImageDisplay
                      photoUrl={meter.photoUrl}
                      meterNumber={meter.meterNumber}
                    />
                  </td>
                  <td>
                    <span className={`status-badge 
                      ${meter.currentReading !== null ? 'status-verified' :
                        meter.currentReading === null ? 'status-pending' : 'status-unread'}`}
                    >
                      {meter.currentReading !== null ? 'อ่านแล้ว' :
                        meter.currentReading === null ? 'ยังไม่ได้อ่าน' : 'ยังไม่ได้อ่าน'}
                    </span>
                  </td>
                  <td className="actions-cell">
                    {meter.status === 'unread' || meter.currentReading === null ? (
                      <button
                        className="action-btn read-btn"
                        onClick={() => handleReadingClick(meter)}
                        disabled={loading}
                      >
                        บันทึก
                      </button>
                    ) : meter.status === 'pending' && user.role_name === 'ADMIN' ? (
                      <button
                        className="action-btn verify-btn"
                        onClick={() => verifyReading(meter.id)}
                        disabled={loading}
                      >
                        ตรวจสอบ
                      </button>
                    ) : (

                      <button
                        className="action-btn edit-btn"
                        onClick={() => handleReadingClick(meter)}
                        disabled={loading}
                      >
                        แก้ไข
                      </button>

                    )}
                    {meter.currentReading !== null ? (
                      <button
                        className="action-btn view-btn"
                        onClick={() => handlePrintSingleBill(meter, currentVillage)}
                        disabled={loading}
                      >
                        PDF
                      </button>
                    ) : null}

                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="11" className="no-data">
                  {loading ? 'กำลังโหลดข้อมูล...' : 'ไม่พบข้อมูลการอ่านมิเตอร์'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Camera Modal */}
      {showCamera && (
        <div className="camera-modal" style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0, 0, 0, 0.9)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000
        }}>
          <div className="camera-container" style={{
            background: 'white',
            borderRadius: '12px',
            padding: '20px',
            maxWidth: '90vw',
            maxHeight: '90vh',
            overflow: 'auto'
          }}>
            <div className="camera-header" style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '20px'
            }}>
              <h3 style={{ margin: 0, fontSize: '1.5rem' }}>ถ่ายรูปมิเตอร์</h3>
              <button
                className="close-camera-btn"
                onClick={stopCamera}
                style={{
                  background: 'none',
                  border: 'none',
                  fontSize: '2rem',
                  cursor: 'pointer',
                  color: '#666'
                }}
              >
                ×
              </button>
            </div>

            <div className="camera-body">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="camera-video"
                style={{
                  width: '100%',
                  maxWidth: '500px',
                  height: 'auto',
                  borderRadius: '8px',
                  display: 'block',
                  margin: '0 auto'
                }}
              />
              <canvas
                ref={canvasRef}
                style={{ display: 'none' }}
              />
            </div>

            <div className="camera-controls" style={{
              display: 'flex',
              justifyContent: 'center',
              gap: '15px',
              marginTop: '20px'
            }}>
              <button
                className="capture-btn"
                onClick={capturePhoto}
                style={{
                  background: '#007bff',
                  color: 'white',
                  border: 'none',
                  padding: '12px 24px',
                  borderRadius: '6px',
                  fontSize: '1rem',
                  cursor: 'pointer'
                }}
              >
                📷 ถ่ายรูป
              </button>
              <button
                className="cancel-camera-btn"
                onClick={stopCamera}
                style={{
                  background: '#6c757d',
                  color: 'white',
                  border: 'none',
                  padding: '12px 24px',
                  borderRadius: '6px',
                  fontSize: '1rem',
                  cursor: 'pointer'
                }}
              >
                ยกเลิก
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reading Form Modal */}
      {showReadingForm && selectedMeter && (
        <div className="modal-overlay">
          <div className="modal-container">
            <div className="modal-header">
              <h2>บันทึกค่ามิเตอร์</h2>
              <button
                className="close-btn"
                onClick={() => {
                  setShowReadingForm(false);
                  setSelectedMeter(null);
                  removeCapturedImage();
                }}
                disabled={loading}
              >
                ×
              </button>
            </div>

            <div className="meter-info">
              <div><strong>เลขมิเตอร์:</strong> {selectedMeter.meterNumber}</div>
              <div><strong>ชื่อผู้ใช้น้ำ:</strong> {selectedMeter.resident}</div>
              <div><strong>ที่อยู่:</strong> {selectedMeter.address}</div>
              <div><strong>เลขมิเตอร์ก่อนหน้า:</strong> {formatNumber(selectedMeter.previousReading)}</div>
              {selectedMeter.currentReading && (
                <div><strong>เลขมิเตอร์ปัจจุบัน:</strong> {formatNumber(selectedMeter.currentReading)}</div>
              )}
            </div>

            <form onSubmit={handleReadingSubmit}>
              <div className="form-group">
                <label>เลขมิเตอร์ปัจจุบัน:</label>
                <input
                  type="number"
                  name="reading"
                  defaultValue={selectedMeter.currentReading || ''}
                  min={selectedMeter.previousReading || 0}
                  step="0.01"  // รองรับทศนิยม 2 ตำแหน่ง
                  required
                  disabled={loading}
                  onInvalid={(e) => {
                    if (e.target.validity.rangeUnderflow) {
                      e.target.setCustomValidity(`ค่ามิเตอร์ต้องมากกว่าหรือเท่ากับ ${selectedMeter.previousReading || 0}`);
                    } else {
                      e.target.setCustomValidity('');
                    }
                  }}
                  onInput={(e) => {
                    e.target.setCustomValidity('');
                  }}
                />
                <div className="hint">
                  * ค่ามิเตอร์ต้องมากกว่าหรือเท่ากับค่าก่อนหน้า ({formatNumber(selectedMeter.previousReading) || '0'})
                </div>
              </div>

              <div className="form-group">
                <label>หมายเหตุ:</label>
                <textarea
                  name="note"
                  defaultValue={selectedMeter.note || ''}
                  disabled={loading}
                ></textarea>
              </div>

              {/* Photo Section */}
              <div className="form-group">
                <label>รูปภาพมิเตอร์:</label>
                <div className="photo-section" style={{
                  border: '2px dashed #ddd',
                  borderRadius: '8px',
                  padding: '20px',
                  textAlign: 'center'
                }}>
                  {capturedImage ? (
                    <div className="captured-image" style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: '15px'
                    }}>
                      <img
                        src={capturedImage.url}
                        alt="รูปที่ถ่าย"
                        className="preview-image"
                        style={{
                          maxWidth: '300px',
                          maxHeight: '200px',
                          objectFit: 'cover',
                          borderRadius: '8px',
                          border: '2px solid #ddd'
                        }}
                      />
                      <div className="image-controls" style={{ display: 'flex', gap: '10px' }}>
                        <button
                          type="button"
                          className="retake-btn"
                          onClick={() => {
                            removeCapturedImage();
                            startCamera();
                          }}
                          disabled={loading}
                          style={{
                            background: '#28a745',
                            color: 'white',
                            border: 'none',
                            padding: '8px 16px',
                            borderRadius: '4px',
                            cursor: 'pointer'
                          }}
                        >
                          📷 ถ่ายใหม่
                        </button>
                        <button
                          type="button"
                          className="remove-photo-btn"
                          onClick={removeCapturedImage}
                          disabled={loading}
                          style={{
                            background: '#dc3545',
                            color: 'white',
                            border: 'none',
                            padding: '8px 16px',
                            borderRadius: '4px',
                            cursor: 'pointer'
                          }}
                        >
                          🗑️ ลบรูป
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="no-image">
                      <p style={{ color: '#666', marginBottom: '15px' }}>ยังไม่มีรูปภาพ</p>
                      <button
                        type="button"
                        className="take-photo-btn"
                        onClick={startCamera}
                        disabled={loading}
                        style={{
                          background: '#28a745',
                          color: 'white',
                          border: 'none',
                          padding: '8px 16px',
                          borderRadius: '4px',
                          cursor: 'pointer'
                        }}
                      >
                        📷 ถ่ายรูปมิเตอร์
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <div className="form-actions">
                <button
                  type="button"
                  className="cancel-btn"
                  onClick={() => {
                    setShowReadingForm(false);
                    setSelectedMeter(null);
                    removeCapturedImage();
                  }}
                  disabled={loading}
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="submit-btn"
                  disabled={loading}
                >
                  {loading ? 'กำลังบันทึก...' : 'บันทึกข้อมูล'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default MeterReadings;